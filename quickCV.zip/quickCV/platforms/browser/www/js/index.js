/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

var itr = 1;
var orderlist = [];

var app = {
    // Application Constructor
    initialize: function() {
        this.bindEvents();
    },
    // Bind Event Listeners
    //
    // Bind any events that are required on startup. Common events are:
    // 'load', 'deviceready', 'offline', and 'online'.
    bindEvents: function() {
        document.addEventListener('deviceready', this.onDeviceReady, false);
    },
    // deviceready Event Handler
    //
    // The scope of 'this' is the event. In order to call the 'receivedEvent'
    // function, we must explicitly call 'app.receivedEvent(...);'
    onDeviceReady: function() {
        app.receivedEvent('deviceready');

        console.log('cordova file: '+cordova.file);
        console.log('cordova file transfer: '+FileTransfer);

    },
    // Update DOM on a Received Event
    receivedEvent: function(id) {
        var parentElement = document.getElementById(id);
        var listeningElement = parentElement.querySelector('.listening');
        var receivedElement = parentElement.querySelector('.received');

        listeningElement.setAttribute('style', 'display:none;');
        receivedElement.setAttribute('style', 'display:block;');

        console.log('Received Event: ' + id);
    },

    basicForm: function (id, e) {

        e.preventDefault();
        app.updateItem( 'basic_details', 'surname', $("#surname").val() );
        app.updateItem( 'basic_details', 'otherNames', $("#otherNames").val() );
        app.updateItem( 'basic_details', 'dob', $("#dob").val() );
        app.updateItem( 'basic_details', 'maritalStatus', $("#maritalStatus").val() );
        app.updateItem( 'basic_details', 'gender', $("#gender").val() );
        app.updateItem( 'basic_details', 'nationality', $("#nationality").val() );
        app.updateItem( 'basic_details', 'lga', $("#lga").val() );
        app.updateItem( 'basic_details', 'language', $("#language").val() );
        app.updateItem( 'basic_details', 'religion', $("#religion").val() );
        app.updateItem( 'basic_details', 'homeTown', $("#homeTown").val() );
        app.updateItem( 'basic_details', 'address', $("#address").val() );
        app.updateItem( 'basic_details', 'state', $("#state").val() );
        app.updateItem( 'basic_details', 'email', $("#email").val() );
        app.updateItem( 'basic_details', 'url', $("#url").val() );
        app.updateItem( 'basic_details', 'tel1', $("#tel1").val() );
        app.updateItem( 'basic_details', 'tel2', $("#tel2").val() );
        app.updateItem( 'basic_details', 'background', $("#backgroundSetting").val() );


        app.quickAlert('Education details was saved');
    },

    hobbiesForm: function (id, e) {

        e.preventDefault();

        app.updateItem( 'hobbies_details', 'hobby1', $("#hobby1").val() );
        app.updateItem( 'hobbies_details', 'hobby2', $("#hobby2").val() );
        app.updateItem( 'hobbies_details', 'hobby3', $("#hobby3").val() );


        app.quickAlert('Hobbies details has been updated!');
    },

    palletEditForm: function (id, e) {

        e.preventDefault();

        var _Array = [ $("#each-pallets-edit1").val(), $("#each-pallets-edit2").val(), $("#each-pallets-edit3").val(), $("#each-pallets-edit4").val(), $("#each-pallets-edit5").val(), 
        $("#each-pallets-edit6").val(), $("#each-pallets-edit7").val(), $("#each-pallets-edit8").val(), $("#each-pallets-edit9").val(), $("#each-pallets-edit10").val() ]

        app.updateItem( 'basic_details', 'palletOrder', _Array );

        app.quickAlert('Pallets values has been updated!');
    },

    palletLayoutForm: function (id, e) {

        e.preventDefault();

        var titles = "", orders = "";

        $("li.ui-state-default").each(function(){
            orders += $(this).attr('data-value')+ ',';
            titles += $(this).text()+ ',';
        });

        var allOrders = orders.split(',');
        var allTitles = titles.split(',');

        var _arrayTitle = [ allTitles[0], allTitles[1], allTitles[2], allTitles[3], allTitles[4], allTitles[5], allTitles[6], allTitles[7], allTitles[8], allTitles[9] ];
        var _arrayOrder = [ allOrders[0], allOrders[1], allOrders[2], allOrders[3], allOrders[4], allOrders[5], allOrders[6], allOrders[7], allOrders[8], allOrders[9] ];

        app.updateItem( 'basic_details', 'palletInOrder', _arrayOrder );
        app.updateItem( 'basic_details', 'palletOrder', _arrayTitle );

        app.quickAlert('Pallets layout has been rearranged!');

        setTimeout(function ()  {

            window.location.reload();

        }, 1500);

    },

    resetPallet: function () {
        var _arrayTitle = [ "PROFESSIONAL SUMMARY", "PERSONAL DETAILS", "EDUCATIONAL BACKGROUND", "WORKING EXPERIENCE", "PROJECT DONE", "SKILLS", "PERSONAL INTERESTS", "AWARDS & ACHIEVEMENTS", "HOBBIES", "REFEREES" ];

        var _arrayOrder = [ "getObjectiveData", "getBasicData", "getEducationData", "getExperienceData", "getProjectData", "getTechnicalData", "getInterestData", "getAchievementData", "getHobbiesData", "getReferenceData" ];

        app.updateItem( 'basic_details', 'palletOrder', _arrayTitle );
        app.updateItem( 'basic_details', 'palletInOrder', _arrayOrder );

        app.quickAlert('Pallets and layouts has been reset!');

        app.getPalletsEdit();
    },
    
    educationForm: function (id, e, index) {

        e.preventDefault();
        
        app.updateItemList( 'education_details', index, 0, $("#institution"+index).val() );
        app.updateItemList( 'education_details', index, 1, $("#course"+index).val() );
        app.updateItemList( 'education_details', index, 2, $("#award"+index).val() );
        app.updateItemList( 'education_details', index, 3, $("#startingDate"+index).val() );
        app.updateItemList( 'education_details', index, 4, $("#endingDate"+index).val() );

        app.quickAlert('Education details has been updated!');

    },

    referenceForm: function (id, e, index) {

        e.preventDefault();
        
        app.updateItemList( 'reference_details', index, 0, $("#referee-names"+index).val() );
        app.updateItemList( 'reference_details', index, 1, $("#referee-designation"+index).val() );
        app.updateItemList( 'reference_details', index, 2, $("#referee-organization"+index).val() );
        app.updateItemList( 'reference_details', index, 3, $("#referee-email"+index).val() );
        app.updateItemList( 'reference_details', index, 4, $("#referee-tel"+index).val() );

        app.quickAlert('Reference details has been updated!');

    },

    experienceForm: function (id, e, index) {

        e.preventDefault();
        
        app.updateItemList( 'experience_details', index, 0, $("#organization"+index).val() );
        app.updateItemList( 'experience_details', index, 1, $("#designation"+index).val() );
        app.updateItemList( 'experience_details', index, 2, $("#startingDate"+index).val() );
        app.updateItemList( 'experience_details', index, 3, $("#endingDate"+index).val() );

        app.quickAlert('Work Experience details has been updated!');

    },

    projectForm: function (id, e, index) {

        e.preventDefault();
        
        app.updateItemList( 'project_details', index, 0, $("#title"+index).val() );
        app.updateItemList( 'project_details', index, 1, $("#desciption"+index).val() );
        app.updateItemList( 'project_details', index, 2, $("#duration"+index).val() );

        app.quickAlert('Project done has been updated!');

    },

    objectiveForm: function (id, e) {

        e.preventDefault();
        
        app.updateItem( 'objective_details', 'objective', $("#objectives").val() );

        app.quickAlert('Objectives has been updated!');

    },

    technicalForm: function (id, e, index) {

        e.preventDefault();
        
        app.updateItemList( 'technical_details', index, 0, $("#skill"+index).val() );

        app.quickAlert('Technical skills has been updated!');

    },

    interestForm: function (id, e, index) {

        e.preventDefault();
        
        app.updateItemList( 'interest_details', index, 0, $("#interest"+index).val() );

        app.quickAlert('Personal Interest has been updated!');

    },

    achievementForm: function (id, e, index) {

        e.preventDefault();
        
        app.updateItemList( 'achievement_details', index, 0, $("#achievement"+index).val() );

        app.quickAlert('Achievement has been updated!');

    },

    updateItemList: function (tabl, index, keys, val) {
        var items = JSON.parse(localStorage.getItem(tabl));
        
        items[index].list[keys] = val;

        // console.log(keep)
        window.localStorage.setItem(tabl, JSON.stringify(items));
    },

    getBasicItems: function () {

        $("#surname").val( app.getItem('basic_details', 'surname') );
        $("#otherNames").val( app.getItem('basic_details', 'otherNames') );
        $("#dob").val( app.getItem('basic_details', 'dob') );

        if ( app.getItem('basic_details', 'maritalStatus') != "")  {
            $('#maritalStatus [value='+app.getItem('basic_details', 'maritalStatus')+']').attr('selected', 'true');
        }

        if ( app.getItem('basic_details', 'religion') != "")  {
            $('#religion [value='+app.getItem('basic_details', 'religion')+']').attr('selected', 'true');
        }

        if ( app.getItem('basic_details', 'gender') != "")  {
            $('#gender [value='+app.getItem('basic_details', 'gender')+']').attr('selected', 'true');
        }

        if ( app.getItem('basic_details', 'nationality') != "")  {
            $("#nationality").val( app.getItem('basic_details', 'nationality') );
        }

        $("#surname").val( app.getItem('basic_details', 'surname') );
        $("#lga").val( app.getItem('basic_details', 'lga') );

        if ( app.getItem('basic_details', 'language') != "")  {
            $("#language").val( app.getItem('basic_details', 'language') );
        }

        $("#homeTown").val( app.getItem('basic_details', 'homeTown') );
        $("#address").val( app.getItem('basic_details', 'address') );
        $("#state").val( app.getItem('basic_details', 'state') );
        $("#email").val( app.getItem('basic_details', 'email') );
        $("#url").val( app.getItem('basic_details', 'url') );
        $("#tel1").val( app.getItem('basic_details', 'tel1') );
        $("#tel2").val( app.getItem('basic_details', 'tel2') );
        $("#backgroundSetting").val( app.getItem('basic_details', 'background') );
    },

    getHobbiesItems: function () {

        $("#hobby1").val( app.getItem('hobbies_details', 'hobby1') );
        $("#hobby2").val( app.getItem('hobbies_details', 'hobby2') );
        $("#hobby3").val( app.getItem('hobbies_details', 'hobby3') );

        if ( $("#hobby1").val() == '' ) {
            $("#hobby1").val('Dancing')
        }
        if ( $("#hobby2").val() == '' ) {
            $("#hobby2").val('Footballing')
        }
        if ( $("#hobby3").val() == '' ) {
            $("#hobby3").val('Travelling')
        }
    },

    getObjectiveItems: function () {

        $("#objectives").val( app.getItem('objective_details', 'objective') );
    },

    setBasicItems: function (opt) {

        if ( !localStorage.getItem('basic_details') || opt == 1 ) {

            var items = {
                            surname: '',
                            otherNames: '',
                            dob: '',
                            maritalStatus: '',
                            gender: '',
                            nationality: '',
                            state: '',
                            lga: '',
                            language: '',
                            religion: '',
                            homeTown: '',
                            address: '',
                            email: '',
                            url: '',
                            tel1: '',
                            tel2: '',
                            passport: '',
                            background: '',
                            palletOrder: ["PROFESSIONAL SUMMARY", "PERSONAL DETAILS", "EDUCATIONAL BACKGROUND", "WORKING EXPERIENCE", "PROJECT DONE", "SKILLS", "PERSONAL INTERESTS", "AWARDS & ACHIEVEMENTS", "HOBBIES", "REFEREES"],
                            palletInOrder: ["getObjectiveData", "getBasicData", "getEducationData", "getExperienceData", "getProjectData", "getTechnicalData", "getInterestData", "getAchievementData", "getHobbiesData", "getReferenceData"]
                        };
            
            window.localStorage.setItem('basic_details', JSON.stringify(items));
        }
    },

    setHobbiesItems: function (opt) {

        if ( !localStorage.getItem('hobbies_details') || opt == 1 ) {

            var items = {
                            hobby1: '',
                            hobby2: '',
                            hobby3: ''
                        };
            
            window.localStorage.setItem('hobbies_details', JSON.stringify(items));
        }
    },

    setObjectiveItems: function (opt) {

        if ( !localStorage.getItem('objective_details') || opt == 1 ) {

            var items = {
                            objective: ''
                        };
            
            window.localStorage.setItem('objective_details', JSON.stringify(items));
        }
    },

    awardSample: function (id, event, index) {
        let value = $(id).val();

        if ( (value == "First Leaving School Certificate (FLSC)") || 
            (value == "Secondary School Certificate of Education (SSCE)") || 
            (value == "West African Examination Council (WAEC)") || 
            (value == "National Examination Council (NECO)") ) {

            $("#course-display"+index).hide();
        }
        else {

            $("#course-display"+index).show();

        }

        $('#award'+index).val( value );
    },

    objectiveSample: function (id) {
        let value = $(id).val();

        $(id).parent().find('#objectives').val( value );
    },

    getEducationItems: function (id) {
        let list = JSON.parse(localStorage.getItem('education_details'));

        if (list.length > 0) {
            var lists = "";
            for (var itr = 0; itr < list.length; itr++) {
                lists += (`
                    <form onsubmit="app.educationForm(this, event, ${itr})" id="education-form${itr}" method="post">
                        <div class="each-qualifications">
                            <h3>Qualification ${ (itr+1) } <button type="button" onclick="app.removeEducation(this, ${itr})" class="btn btn-sm btn-danger">Delete</button></h3>

                            <div class="form-group">
                                <label for="institution${itr}">Name of School:</label>
                                <input id="institution${itr}" value="${app.getArrayListVal('education_details', itr, 0)}" type="text" class="form-control input-lg" placeholder="Name of School" required>
                            </div>

                            <div class="form-group">
                                <label for="award${itr}">Award:</label>
                                <select onchange="app.awardSample(this, event, ${itr})" class="form-control input-sm">
                                    <option>Select sample</option>
                                    <option>First Leaving School Certificate (FLSC)</option>
                                    <option>Secondary School Certificate of Education (SSCE)</option>
                                    <option>West African Examination Council (WAEC)</option>
                                    <option>National Examination Council (NECO)</option>
                                    <option>General Certificate of Education (Ordinary Level)</option>
                                    <option>General Certificate of Education (Advanced Level)</option>
                                    <option>Ordinary National Diploma (OND)</option>
                                    <option>Nigerian Certificate of Education (NCE)</option>
                                    <option>Higher National Diploma (HND)</option>
                                    <option>University Degree   (First Degree)</option>
                                    <option>Doctor of Veterinary Medicine</option>  
                                    <option>Postgraduate Diploma (PGD)</option>
                                    <option>Masters Degree  (MSC)</option>
                                    <option>Doctor of Philosophy (PHD)</option>
                                </select>
                                <input id="award${itr}" type="text" value="${app.getArrayListVal('education_details', itr, 2)}" class="form-control input-lg" placeholder="(Example: Higher National Diploma (HND) )">
                            </div>

                            <div class="form-group" id="course-display${itr}">
                                <label for="course${itr}">Course of study:</label>
                                <input id="course${itr}" type="text" value="${app.getArrayListVal('education_details', itr, 1)}" class="form-control input-lg" placeholder="Course of study">
                            </div>

                            <div class="row">
                                <div class="col-xs-6">
                                    <div class="form-group">
                                        <label for="startingDate${itr}">Starting date:</label>
                                        <input id="startingDate${itr}" value="${app.getArrayListVal('education_details', itr, 3)}" type="month" class="form-control input-lg" placeholder="Starting date" required>
                                    </div>
                                </div>
                            
                                <div class="col-xs-6">
                                    <div class="form-group">
                                        <label for="endingDate${itr}">Ending date:</label>
                                        <input id="endingDate${itr}" value="${app.getArrayListVal('education_details', itr, 4)}" type="month" class="form-control input-lg" placeholder="Ending date" required>
                                    </div>
                                </div>
                            </div>  
                        </div>
                        <hr>
                        <button type="submit" class="btn btn-primary btn-lg btn-block">Submit</button>
                        <hr>
                    </form>
                    `)
            }

            $("#all-qualifications").html(lists)
            $("#all-qualifications").after(`<button type="button" onclick="app.setEducationItems(this)" class="btn btn-warning btn-block btn-lg">Add more</button>`)

        }
    },

    getReferenceItems: function (id) {
        let list = JSON.parse(localStorage.getItem('reference_details'));

        if (list.length > 0) {
            var lists = "";
            for (var itr = 0; itr < list.length; itr++) {
                lists += (`

                    <form onsubmit="app.referenceForm(this, event, ${itr})" id="reference-form${itr}" method="post">
                        <h3>Reference ${ (itr+1) } <button type="button" onclick="app.removeReference(this, ${itr})" class="btn btn-sm btn-danger">Delete</button></h3>
                        <label for="referee-names${itr}">Full names:</label><br>
                        <input id="referee-names${itr}" value="${app.getArrayListVal('reference_details', itr, 0)}" class="form-control input-lg" type="text" placeholder="Full names" required><br><br>

                        <label for="referee-1${itr}">Degination:</label><br>
                        <input id="referee-designation${itr}" value="${app.getArrayListVal('reference_details', itr, 1)}" class="form-control input-lg" type="text" placeholder="Degination" required><br><br>

                        <label for="referee-organization${itr}">Organization:</label><br>
                        <input id="referee-organization${itr}" value="${app.getArrayListVal('reference_details', itr, 2)}" class="form-control input-lg" type="text" placeholder="Organization" required><br><br>

                        <label for="referee-email${itr}">Email Address:</label><br>
                        <input id="referee-email${itr}" value="${app.getArrayListVal('reference_details', itr, 3)}" class="form-control input-lg" type="email" placeholder="Email Address"><br><br>
                        
                        <label for="referee-tel${itr}">Phone Number:</label><br>
                        <input id="referee-tel${itr}" value="${app.getArrayListVal('reference_details', itr, 4)}" class="form-control input-lg" type="tel" placeholder="Phone Number"><br><br>

                        <hr>
                        <button type="submit" class="btn btn-block btn-primary btn-lg">Submit</button>
                        <hr>

                    </form>
                `)
            }

            $("#all-references").html(lists)
            $("#all-references").after(`<button type="button" onclick="app.setReferenceItems(this)" class="btn btn-warning btn-block btn-lg">Add more</button>`)
        }
    },

    getExperienceItems: function (id) {
        let list = JSON.parse(localStorage.getItem('experience_details'));

        // ${ getArrayListVal('education_details', 'institution', itr )}

        if (list.length > 0) {
            var lists = "";
            for (var itr = 0; itr < list.length; itr++) {
                lists += (`
                    <form onsubmit="app.experienceForm(this, event, ${itr})" id="experience-form${itr}" method="post">
                        <div class="each-experience" id="experience${itr}">
                            <h3>Experience ${ (itr+1) } <button type="button" onclick="app.removeExperience(this, ${itr})" class="btn btn-sm btn-danger">Delete</button></h3>

                            <div class="form-group">
                                <label for="organization${itr}">Name of Organization:</label>
                                <input id="organization${itr}" value="${app.getArrayListVal('experience_details', itr, 0)}" type="text" class="form-control input-lg" placeholder="Organization" required>
                            </div>

                            <div class="form-group">                        
                                <label for="designation${itr}">Designation (Role):</label>
                                <input id="designation${itr}" value="${app.getArrayListVal('experience_details', itr, 1)}" class="form-control input-lg" placeholder="(E.G Manager)" required>
                            </div>

                            <div class="row">
                                <div class="col-xs-6">
                                    <div class="form-group">
                                        <label for="startingDate${itr}">Starting date:</label>
                                        <input id="startingDate${itr}" value="${app.getArrayListVal('experience_details', itr, 2)}" type="month" class="form-control input-lg" placeholder="Starting date" required>
                                    </div>
                                </div>
                            
                                <div class="col-xs-6">
                                    <div class="form-group">
                                        <label for="endingDate${itr}">Ending date:</label>
                                        <input id="endingDate${itr}" value="${app.getArrayListVal('experience_details', itr, 3)}" type="month" class="form-control input-lg" placeholder="Ending date" required>
                                    </div>
                                </div>
                            </div>  
                        </div>
                   
                        <hr>
                        <button type="submit" class="btn btn-block btn-primary btn-lg">Submit</button>
                        <hr>
                    </form>
                `)
            }

            $("#all-experiences").html(lists)
            $("#all-experiences").after(`<button type="button" onclick="app.setExperienceItems(this)" class="btn btn-warning btn-block btn-lg">Add more</button>`)
        }
    },

    getTemplate1: function (id) {

        var tableData = (`
                <table border="0">
                    <thead>
                        <tr align="center">
                            <th colspan="4"  style="padding: 10px; font-size: 35px; font-weight: bold; text-align: center;">
                                ${ app.getItem('basic_details', 'surname') +' '+ app.getItem('basic_details', 'otherNames') }
                            </th>
                        </tr>
                    </thead>
                    <tbody>                    
                        <tr align="center">
                            <td colspan="4" style="padding: 10px; color: black; font-size:14pt; font-style: italic; ">
                                ${ app.getItem('basic_details', 'address') }
                            </td>
                        </tr>
                    
                        ${ app.getDataInOrder1() }
                    </tbody>
                    
            </table>
        `);

        
        
        $('#template-1-container').html(tableData);
        
        // var name = app.getItem('basic_details', 'surname') +' '+ app.getItem('basic_details', 'otherNames');
        
        /*$("#template-1-container").
            after(`
                <form id="download-form" onsubmit="app.downloadForm(event, this)" method="post">
                    <textarea name="data" style="display:none;">${tableData}</textarea>

                    <input name="name" value="${name}" style="display:none;">

                    <a id="download-link" style="position: fixed; bottom: 0; right: 0; left: 0; width: 100%;" class="btn btn-danger btn-block btn-lg" href="http://9ja-fast-data.hit.ng/PDF-Generator/examples/example_048.php?name=${name}" onclick="window.open('http://9ja-fast-data.hit.ng/PDF-Generator/examples/example_048.php?name=${name}', '_system'); return false;">Save as PDF</a>
                `);*/
            // $("form#download-form").submit();
    },

    openTemplateBrowser: function (page) {
        
        var isCordovaApp = !!window.cordova;

        if( isCordovaApp ) {  

           var url = page;
           var target = '_system';
           var options = "location = yes"
           var ref = cordova.InAppBrowser.open(url, target, options);       
       
           ref.addEventListener('loadstart', loadstartCallback);
           ref.addEventListener('loadstop', loadstopCallback);
           ref.addEventListener('loaderror', loaderrorCallback);
           ref.addEventListener('exit', exitCallback);

           function loadstartCallback(event) {
              console.log('Loading started: '  + event.url)
           }

           function loadstopCallback(event) {
              console.log('Loading finished: ' + event.url)
           }

           function loaderrorCallback(error) {
              console.log('Loading error: ' + error.message)
           }

           function exitCallback() {
              console.log('Browser is closed...')
           }
       }else {

            window.location.href = page;
       }
    },

    generatePDF: function(id) {
        
        $(id).tableExport({
            fileName:   'Tommy CV',
            type:       'pdf',
            unit:       'pt',
            theme:      'grid',
            jspdf: {
                orientation: 'p',
                margins: {left:10, right:10, top:20, bottom:20},
                autotable: {
                    styles: {
                        fillColor: 'inherit',
                        textColor: 'inherit',
                        fontStyle: 'inherit',
                        fontSize:   13,
                        rowHeight: 20,
                        cellPadding: 10,
                        overflow: 'visible'

                    },
                    tableWidth: 'wrap'
                }
            },

            tableExport: {
                onBeforeAutotable: function (table, headers, rows, AutotableSettings) {

                },
                onCellData: function (cell, row, col, data) {

                }
            }
        });

        console.log(store)
    },

    getDataInOrder1: function ( ) {

        var palletInOrder = app.getItem('basic_details', 'palletInOrder');
        var palletTitle = app.getItem('basic_details', 'palletOrder');

        var data = "";

        data += eval('app.'+palletInOrder[0]+'(palletTitle[0])')
        data += eval('app.'+palletInOrder[1]+'(palletTitle[1])')
        data += eval('app.'+palletInOrder[2]+'(palletTitle[2])')
        data += eval('app.'+palletInOrder[3]+'(palletTitle[3])')
        data += eval('app.'+palletInOrder[4]+'(palletTitle[4])')
        data += eval('app.'+palletInOrder[5]+'(palletTitle[5])')
        data += eval('app.'+palletInOrder[6]+'(palletTitle[6])')
        data += eval('app.'+palletInOrder[7]+'(palletTitle[7])')
        data += eval('app.'+palletInOrder[8]+'(palletTitle[8])')
        data += eval('app.'+palletInOrder[9]+'(palletTitle[9])')
                    
        return data;       
            
    },

    getDataInOrder2: function ( ) {

        var palletInOrder = app.getItem('basic_details', 'palletInOrder');
        var palletTitle = app.getItem('basic_details', 'palletOrder');

        var data = "";

        data += app.getHeaderData2()
        data += eval('app.'+palletInOrder[0]+'2(palletTitle[0])')
        data += eval('app.'+palletInOrder[1]+'2(palletTitle[1])')
        data += eval('app.'+palletInOrder[2]+'2(palletTitle[2])')
        data += eval('app.'+palletInOrder[3]+'2(palletTitle[3])')
        data += eval('app.'+palletInOrder[4]+'2(palletTitle[4])')
        data += eval('app.'+palletInOrder[5]+'2(palletTitle[5])')
        data += eval('app.'+palletInOrder[6]+'2(palletTitle[6])')
        data += eval('app.'+palletInOrder[7]+'2(palletTitle[7])')
        data += eval('app.'+palletInOrder[8]+'2(palletTitle[8])')
        data += eval('app.'+palletInOrder[9]+'2(palletTitle[9])')
                    
        return data;       
            
    },

    getTemplate2: function (id) {

        var palletTitle = app.getItem('basic_details', 'palletOrder');

        var name = app.getItem('basic_details', 'surname') +' '+ app.getItem('basic_details', 'otherNames');
        var tableData = (`
                <table border="0" cellspacing="0" style="font-size: 13pt;">
                    <tbody>
                        <tr>
                            <td width="30%" style="background-color: ${ app.getItem('basic_details', 'background') }; color: white; padding-left: 5px; text-align: center; font-weight: bold; border-bottom: 5px solid ${ app.getItem('basic_details', 'background') };" rowspan="3"><img id="my-live-passport" src="images/${name}.png" style="width: 90%; height: 150px; margin-top: 10px;"></td>
                            <td width="70%" colspan="3"></td>
                        </tr>
                        <tr>
                            <td colspan="3" style="padding: 5px; font-size: 20pt; font-weight: bold; text-align: center;">${ app.getItem('basic_details', 'surname') +' '+ app.getItem('basic_details', 'otherNames')}</td>
                        </tr>
                       ${ app.getDataInOrder2() }  
                    </tbody>
                </table>
        `);

        var name = app.getItem('basic_details', 'surname') +' '+ app.getItem('basic_details', 'otherNames');
        
        $('#template-2-container').html(tableData);
        $("#template-2-container").
            after(`
                <form id="download-form" onsubmit="app.downloadForm(event, this)" method="post">
                    <textarea name="data" style="display:none;">${tableData}</textarea>

                    <input name="name" value="${name}" style="display:none;">

                    <input name="passport" value="${ app.getItem('basic_details', 'passport') }" style="display:none;">

                    <a id="download-link" style="position: fixed; bottom: 0; right: 0; left: 0; width: 100%; margin: 0;" class="btn btn-danger btn-block btn-lg" href="http://9ja-fast-data.hit.ng/PDF-Generator/examples/example_048_2.php?name=${name}" onclick="window.open('http://9ja-fast-data.hit.ng/PDF-Generator/examples/example_048_2.php?name=${name}', '_system'); return false;">Save as PDF</a>
                `);
            // $("form#download-form").submit();
    },

    downloadForm: function (e, id) {
        
        e.preventDefault();

        if(navigator.onLine){

            $("#downloadModal").modal('hide');

            app.quickAlert('Wait for your file to be downloaded');

            $.post("http://9ja-fast-data.hit.ng/PDF-Generator/examples/save.php", $(id).serialize() ).done(function (data) {
                
                $('#download-link').click();

            }).fail(function () {

                app.quickAlert('File could not be downloaded, please check your internet connection and try again!');
            });
        }else {

            $("#downloadModal").modal('show')
        }
    },

    getProjectItems: function (id) {
        let list = JSON.parse(localStorage.getItem('project_details'));

        if (list.length > 0) {

            var lists = "";
            for (var itr = 0; itr < list.length; itr++) {
                lists += (`
                    <form onsubmit="app.projectForm(this, event, ${itr})" id="project-form${itr}" method="post">
                        <div class="each-project">
                            <h3>Project ${ (itr+1) } <button type="button" onclick="app.removeProject(this, ${itr})" class="btn btn-sm btn-danger">Delete</button></h3>

                            <div class="form-group">
                                <label for="title${itr}">Title:</label>
                                <input id="title${itr}" type="text" value="${app.getArrayListVal('project_details', itr, 0)}" class="form-control input-lg" placeholder="Title" required>
                            </div>

                            <div class="form-group">                        
                                <label for="desciption${itr}">Desciption:</label>
                                <textarea id="desciption${itr}" class="form-control input-lg" type="text" placeholder="Desciption" required>${app.getArrayListVal('project_details', itr, 1)}</textarea>
                            </div>

                            <div class="form-group">                        
                                <label for="duration${itr}">Duration:</label>
                                <input id="duration${itr}" type="text" value="${app.getArrayListVal('project_details', itr, 2)}" class="form-control input-lg" placeholder="(Example:  1 Month)" required>
                            </div>
                        </div>

                        <button type="submit" class="btn btn-block btn-primary btn-lg">Submit</button>
                        <hr>
                    </form>
                `)
            }

            $("#all-projects").html(lists)
            $("#all-projects").after(`<button type="button" onclick="app.setProjectItems(this)" class="btn btn-warning btn-block btn-lg">Add more</button>`)
        }
    },

    getBasicData: function (id) {
        var list = "";

        list += `<tr>
                    <td colspan="4" style="background-color: ${ app.getItem('basic_details', 'background') }; color: white; padding: 10px; font-size: 14pt; font-weight: bold;">${id}:</td>
                </tr>`;

        if ( app.getItem('basic_details', 'gender') != "") {

            list += `<tr>
                        <th style="font-weight: bold;">Gender:</th>
                        <td colspan="3" style="padding: 10px; font-size: 14pt;">
                            ${ app.getItem('basic_details', 'gender') }
                        </td>
                    </tr>`;
        }
        if ( app.getItem('basic_details', 'dob') != "") {

            list += `<tr>
                        <th style="font-weight: bold;">Date of Birth:</th>
                        <td colspan="3" style="padding: 10px; font-size: 14pt;">
                            ${ app.getDOB(app.getItem('basic_details', 'dob')) }
                        </td>
                    </tr>`;
        }
        if ( app.getItem('basic_details', 'tel1') != "") {

            list += `<tr>
                        <td style="padding: 10px; font-size: 14pt;">Phone Number:</td>
                        <td colspan="3" style="padding: 10px; font-size: 14pt;">
                            ${ app.getItem('basic_details', 'tel1') } , ${ app.getItem('basic_details', 'tel2') }
                        </td>
                    </tr>`;
        }

        if ( app.getItem('basic_details', 'email') != "") {

            list += `<tr>
                        <td style="padding: 10px; font-size: 14pt;"><b>Email:</b></td>
                        <td colspan="3" align="left" style="padding: 10px; font-size: 14pt;">
                            ${ app.getItem('basic_details', 'email') }
                        </td>
                    </tr>`;
        }

        if ( app.getItem('basic_details', 'maritalStatus') != "") {

            list += `<tr>
                        <td style="padding: 10px; font-size: 14pt;"><b>Marital Status:</b></td>
                        <td style="padding: 10px; font-size: 14pt;">
                            ${ app.getItem('basic_details', 'maritalStatus') }
                        </td>
                    </tr>`;
        }

        if ( app.getItem('basic_details', 'nationality') != "") {

            list += `<tr>
                        <td style="padding: 10px; font-size: 14pt;"><b>Nationality:</b></td>
                        <td colspan="3" style="padding: 10px; font-size: 14pt;">
                            ${ app.getItem('basic_details', 'nationality') }
                        </td>
                    </tr>`;
        }

        if ( app.getItem('basic_details', 'state') != "") {

            list += `<tr>
                        <td style="padding: 10px; font-size: 14pt;"><b>State of Origin:</b></td>
                        <td colspan="3" style="padding: 10px; font-size: 14pt;">
                            ${ app.getItem('basic_details', 'state') }
                        </td>
                    </tr>`;
        }

        if ( app.getItem('basic_details', 'homeTown') != "" ) {

            list += `<tr>
                        <td style="padding: 10px; font-size: 14pt;"><b>Home Town:</b></td>
                        <td colspan="3" style="padding: 10px; font-size: 14pt;">
                            ${ app.getItem('basic_details', 'homeTown') }
                        </td>
                    </tr>`;
        }

        if ( app.getItem('basic_details', 'lga') != "" ) {

            list += `<tr>
                        <td style="padding: 10px; font-size: 14pt;"><b>Local Govt.:</b></td>
                        <td colspan="3" style="padding: 10px; font-size: 14pt;">
                            ${ app.getItem('basic_details', 'lga') }
                        </td>
                    </tr>`;
        }

        if ( app.getItem('basic_details', 'religion') != "" ) {

            list += `<tr>
                        <td style="padding: 10px; font-size: 14pt;"><b>Religion:</b></td>
                        <td colspan="3" style="padding: 10px; font-size: 14pt;">
                            ${ app.getItem('basic_details', 'religion') }
                        </td>
                    </tr>`;
        }

        return list; 
    },

    getBasicData2: function (id) {
        var list = "";

        var numRows = 1;
        if ( app.getItem('basic_details', 'gender') != "") {

            numRows++;
        }
        if ( app.getItem('basic_details', 'dob') != "") {

            numRows++;
        }

        if ( app.getItem('basic_details', 'maritalStatus') != "") {

            numRows++;
        }

        if ( app.getItem('basic_details', 'nationality') != "") {

           numRows++;
        }

        if ( app.getItem('basic_details', 'state') != "") {

            numRows++;
        }

        if ( app.getItem('basic_details', 'homeTown') != "" ) {

            numRows++;
        }

        if ( app.getItem('basic_details', 'lga') != "" ) {

            numRows++;
        }

        if ( app.getItem('basic_details', 'religion') != "" ) {

            numRows++;
        }


        list += `<tr>
                    <td valign="top" rowspan="${numRows}" style="background-color: ${ app.getItem('basic_details', 'background') }; color: white; padding-left: 5px; font-weight: bold; border-bottom: 5px solid ${ app.getItem('basic_details', 'background') };">${id}:</td>
                    <td colspan="4" style="border-top: 5px solid ${ app.getItem('basic_details', 'background') };"></td>
                </tr>`

        if ( app.getItem('basic_details', 'gender') != "") {

            list += `<tr>
                        <td style="padding: 5px;"><b>Gender:</b></td>
                        <td colspan="2">${ app.getItem('basic_details', 'gender') }</td>
                    </tr>`;
        }
        if ( app.getItem('basic_details', 'dob') != "") {

            list += `<tr>
                        <td style="padding: 5px;"><b>Date of birth:</b></td>
                        <td colspan="2">${ app.getDOB( app.getItem('basic_details', 'dob') ) }</td>
                    </tr>`;
        }

        if ( app.getItem('basic_details', 'maritalStatus') != "") {

            list += `<tr>
                        <td style="padding: 5px;"><b>Marital Status:</b></td>
                            <td colspan="2">${ app.getItem('basic_details', 'maritalStatus') }
                        </td>
                    </tr>`;
        }

        if ( app.getItem('basic_details', 'nationality') != "") {

            list += `<tr>
                        <td style="padding: 5px;"><b>Nationality:</b></td>
                            <td colspan="2">${ app.getItem('basic_details', 'nationality') }
                        </td>
                    </tr>`;
        }

        if ( app.getItem('basic_details', 'state') != "") {

            list += `<tr>
                        <td style="padding: 5px;"><b>State of Origin:</b></td>
                            <td colspan="2">${ app.getItem('basic_details', 'state') }
                        </td>
                    </tr>`;
        }

        if ( app.getItem('basic_details', 'homeTown') != "" ) {

            list += `<tr>
                        <td style="padding: 5px;"><b>Home Town:</b></td>
                            <td colspan="2">${ app.getItem('basic_details', 'homeTown') }
                        </td>
                    </tr>`;
        }

        if ( app.getItem('basic_details', 'lga') != "" ) {

            list += `<tr>
                        <td style="padding: 5px;"><b>Local Govt.:</b></td>
                            <td colspan="2">${ app.getItem('basic_details', 'lga') }
                        </td>
                    </tr>`;
        }

        if ( app.getItem('basic_details', 'religion') != "" ) {

            list += `<tr>
                        <td style="padding: 5px;"><b>Religion:</b></td>
                            <td colspan="2">${ app.getItem('basic_details', 'religion') }
                        </td>
                    </tr>`;
        }

        return list; 
    },

    getEducationData2: function (id) {
        var list = "";

        if ( app.getArrayListVal('education_details', 0, 0) != "") {

            var numRows = 1;
            for (var itr = 0; itr < JSON.parse(localStorage.getItem('education_details')).length; itr++) {
                    
                if ( app.getArrayListVal('education_details', itr, 0) != "") {

                    numRows++;
                }
            }

            list += (`<tr>
                            <td valign="top" rowspan="${numRows}" style="background-color: ${ app.getItem('basic_details', 'background') }; color: white; padding-left: 5px; font-weight: bold; border-bottom: 5px solid ${ app.getItem('basic_details', 'background') };">${id}:</td>
                            <td colspan="3" style="border-top: 5px solid ${ app.getItem('basic_details', 'background') };"></td>
                    </tr>
                    `)

            if (JSON.parse(localStorage.getItem('education_details')).length > 0) {
                for (var itr = 0; itr < JSON.parse(localStorage.getItem('education_details')).length; itr++) {
                    
                    if ( app.getArrayListVal('education_details', itr, 0) != "") {

                        numRows++;

                        list += (`
                                <tr>
                                    <td width="45%"><font style="font-size: 20pt;">&#8226; &nbsp;</font><b>${ app.getArrayListVal('education_details', itr, 0) }</b><br>
                                        &nbsp;&nbsp;${ app.getArrayListVal('education_details', itr, 1) }<br>
                                        &nbsp;&nbsp;${ app.getArrayListVal('education_details', itr, 2) }
                                    </td>
                                    <td width="25%" style="font-weight: bold;">
                                        ${ app.monthDate( app.getArrayListVal('education_details', itr, 3) ) } - ${ app.monthDate( app.getArrayListVal('education_details', itr, 4) ) }
                                    </td>
                                </tr>
                        `);
                    }
                }
            }

        }

        return list; 
    },

    getEducationData: function (id) {
        var list = "";

        if ( app.getArrayListVal('education_details', 0, 0) != "") {

            list += (`<tr>
                        <td style="background-color: ${ app.getItem('basic_details', 'background') }; color: white; padding: 10px; font-size: 14pt; font-weight: bold;" colspan="4">${id}:</td>
                    </tr>`);

            if (JSON.parse(localStorage.getItem('education_details')).length > 0) {
                for (var itr = 0; itr < JSON.parse(localStorage.getItem('education_details')).length; itr++) {
                    
                    if ( app.getArrayListVal('education_details', itr, 0) != "") {
                        list += (`
                            <tr>
                                <td width="70%" style="padding: 10px; font-size: 14pt;" colspan="3"><font style="font-size: 20pt;">&#8226; &nbsp;</font><b>${ app.getArrayListVal('education_details', itr, 0) }</b><br>
                                    &nbsp;&nbsp;${ app.getArrayListVal('education_details', itr, 1) }<br>
                                    &nbsp;&nbsp;${ app.getArrayListVal('education_details', itr, 2) }
                                </td>
                                <td width="30%" style="padding: 10px; font-size: 14pt; font-weight: bold;">
                                    ${ app.monthDate( app.getArrayListVal('education_details', itr, 3) ) } - ${ app.monthDate( app.getArrayListVal('education_details', itr, 4) ) }
                                </td>
                            </tr>
                        `);
                    }
                }
            }
        }

        return list; 
    },

    getHobbiesData: function (id) {
        var list = "";

        if ( app.getItem('hobbies_details', 'hobby1') != "") {

            list += (`<tr>
                        <td style="background-color: ${ app.getItem('basic_details', 'background') }; color: white; padding: 10px; font-size: 14pt; font-weight: bold;" colspan="4">${id}:</td>
                    </tr>

                    <tr>
                        <td style="padding: 10px; font-size: 14pt;" colspan="4"><font style="font-size: 20pt;">&#8226; &nbsp;</font> ${ app.getItem('hobbies_details', 'hobby1') }
                        </td>
                    </tr>

                    `)
        }

        if ( app.getItem('hobbies_details', 'hobby2') != "") {
                list += (`<tr>
                            <td style="padding: 10px; font-size: 14pt;" colspan="4"><font style="font-size: 20pt;">&#8226; &nbsp;</font>${ app.getItem('hobbies_details', 'hobby2') }</td>
                         </tr>
                        `)
        }

        if ( app.getItem('hobbies_details', 'hobby3') != "") {
                list += (`<tr>
                            <td style="padding: 10px; font-size: 14pt;" colspan="4"><font style="font-size: 20pt;">&#8226; &nbsp;</font>${ app.getItem('hobbies_details', 'hobby3') }</td>
                         </tr>
                        `)
        }
                    

        return list; 
    },

    getHobbiesData2: function (id) {
        var list = "";

        var numRows = 1;

        if ( app.getItem('hobbies_details', 'hobby1') != "") {

            numRows++;
        }

        if ( app.getItem('hobbies_details', 'hobby2') != "") {
             numRows++;
        }

        if ( app.getItem('hobbies_details', 'hobby3') != "") {
            numRows++;
        }

        if ( app.getItem('hobbies_details', 'hobby1') != "") {           

            list += (`<tr>
                            <td rowspan="${numRows}" style="background-color: ${ app.getItem('basic_details', 'background') }; color: white; padding-left: 5px; font-weight: bold; border-bottom: 5px solid ${ app.getItem('basic_details', 'background') };">${id}:</td>
                            <td colspan="4" style="border-top: 5px solid ${ app.getItem('basic_details', 'background') };">
                    </td></tr>
                    `)

            if ( app.getItem('hobbies_details', 'hobby1') != "") {

                list += (`<tr>
                            <td colspan="2"><font style="font-size: 20pt;">&#8226; &nbsp;</font> ${ app.getItem('hobbies_details', 'hobby1') }
                            </td>
                        </tr>

                        `)
            }

            if ( app.getItem('hobbies_details', 'hobby2') != "") {
                    list += (`<tr>
                                <td colspan="2"><font style="font-size: 20pt;">&#8226; &nbsp;</font>${ app.getItem('hobbies_details', 'hobby2') }</td>
                             </tr>
                            `)
            }

            if ( app.getItem('hobbies_details', 'hobby3') != "") {
                    list += (`<tr>
                                <td colspan="2"><font style="font-size: 20pt;">&#8226; &nbsp;</font>${ app.getItem('hobbies_details', 'hobby3') }</td>
                             </tr>
                            `)
            }
        }                

        return list; 
    },

    getObjectiveData: function (id) {
        var list = "";

        if ( app.getItem('objective_details', 'objective') != "") {

            list += (`<tr>
                        <td style="background-color: ${ app.getItem('basic_details', 'background') }; color: white; padding: 10px; font-size: 14pt; font-weight: bold;" colspan="4">${id}:</td>
                    </tr>
                    <tr>
                        <td style="padding: 10px; font-size: 14pt;" colspan="4">${ app.getItem('objective_details', 'objective') }</td>
                    </tr>`);
        }

        return list; 
    },

    getHeaderData2: function () {
        var list = "";
        
        list += `<tr> 
                    <td valign="top" colspan="3" align="center" style="border-bottom: 5px solid ${ app.getItem('basic_details', 'background') }; font-size: 14pt;">
                `;
        if ( app.getItem('basic_details', 'address') != "") {

            list += (`${ app.getItem('basic_details', 'address') }<br>`)
        }

        if ( app.getItem('basic_details', 'email') != "") {
                                
            list += (`<b>Email:</b>
                        ${ app.getItem('basic_details', 'email')}<br>
                    `)
        }
        if ( app.getItem('basic_details', 'url') != "") {
                                
            list += (`<b>Website:</b>
                        ${ app.getItem('basic_details', 'url')}<br>
                    `)
        }

        if ( app.getItem('basic_details', 'tel1') != "") {
                                
            list += (`<b>Tel:</b>
                        ${ app.getItem('basic_details', 'tel1') +', '+  app.getItem('basic_details', 'tel1') }
                        </td>
                    </tr>`);
        }

        return list; 
    },

    getObjectiveData2: function (id) {
        var list = "";

        if ( app.getItem('objective_details', 'objective') != "") {

            list += (`<tr>
                        <td valign="top" style="background-color: ${ app.getItem('basic_details', 'background') }; color: white; padding-left: 5px; font-weight: bold; border-bottom: 5px solid ${ app.getItem('basic_details', 'background') };">${id}:</td>
                        <td colspan="3" style="padding: 5px; border-top: 5px solid ${ app.getItem('basic_details', 'background') };"> ${ app.getItem('objective_details', 'objective') }</td>
                    </tr>`);
        }

        return list; 
    },

    getReferenceData: function (id) {
        var list = "";

        if ( app.getArrayListVal('reference_details', 0, 0) != "") {

            list += (`<tr>
                        <td style="background-color: ${ app.getItem('basic_details', 'background') }; color: white; padding: 10px; font-size: 14pt; font-weight: bold;" colspan="4">${id}:</td>
                    </tr>`);
            if (JSON.parse(localStorage.getItem('reference_details')).length > 0) {
                for (var itr = 0; itr < JSON.parse(localStorage.getItem('reference_details')).length; itr++) {

                    if ( app.getArrayListVal('reference_details', itr, 0) != "") {

                        list += (`
                            <tr>
                                <td style="padding: 10px; font-size: 14pt;" colspan="3"><font style="font-size: 20pt;">&#8226; &nbsp;</font><b>${ app.getArrayListVal('reference_details', itr, 0) }</b><br>
                                &nbsp;${ app.getArrayListVal('reference_details', itr, 1) }<br>
                                &nbsp;${ app.getArrayListVal('reference_details', itr, 2) }<br>
                                &nbsp;${ app.getArrayListVal('reference_details', itr, 3) }<br>
                                &nbsp;${ app.getArrayListVal('reference_details', itr, 4) }
                                </td>
                            </tr>
                        `);
                    }
                }
            }
        }

        return list; 
    },

    getReferenceData2: function (id) {
        var list = "";

        if ( app.getArrayListVal('reference_details', 0, 0) != "") {

            var numRows = 1;
            for (var itr = 0; itr < JSON.parse(localStorage.getItem('reference_details')).length; itr++) {
                    
                if ( app.getArrayListVal('reference_details', itr, 0) != "") {

                    numRows++;
                }
            }

            list += (`<tr>
                            <td valign="top" rowspan="${numRows}" style="background-color: ${ app.getItem('basic_details', 'background') }; color: white; padding-left: 5px; font-weight: bold; border-bottom: 5px solid ${ app.getItem('basic_details', 'background') };">${id}:</td>
                            <td colspan="2" style="border-top: 5px solid ${ app.getItem('basic_details', 'background') };">
                    </td></tr>
                    `)

            if (JSON.parse(localStorage.getItem('reference_details')).length > 0) {
                for (var itr = 0; itr < JSON.parse(localStorage.getItem('reference_details')).length; itr++) {

                    if ( app.getArrayListVal('reference_details', itr, 0) != "") {

                        list += (`
                            <tr>
                                <td colspan="2"><font style="font-size: 20pt;">&#8226; &nbsp;</font><b>${ app.getArrayListVal('reference_details', itr, 0) }</b><br>
                                &nbsp;${ app.getArrayListVal('reference_details', itr, 1) }<br>
                                &nbsp;${ app.getArrayListVal('reference_details', itr, 2) }<br>
                                &nbsp;${ app.getArrayListVal('reference_details', itr, 3) }<br>
                                &nbsp;${ app.getArrayListVal('reference_details', itr, 4) }
                                </td>
                            </tr>
                        `);
                    }
                }
            }
        }

        return list; 
    },

    getExperienceData: function (id) {
        var list = "";

        if ( app.getArrayListVal('experience_details', 0, 0) != "") {

            list += (`<tr>
                        <td style="background-color: ${ app.getItem('basic_details', 'background') }; color: white; padding: 10px; font-size: 14pt; font-weight: bold;" colspan="4">${id}:</td>
                    </tr>`);

            if (JSON.parse(localStorage.getItem('experience_details')).length > 0) {
                for (var itr = 0; itr < JSON.parse(localStorage.getItem('experience_details')).length; itr++) {

                    if ( app.getArrayListVal('experience_details', itr, 0) != "") {
                        list += (`
                            <tr>
                                <td style="padding: 10px; font-size: 14pt;" colspan="3"><font style="font-size: 20pt;">&#8226; &nbsp;</font><b>${ app.getArrayListVal('experience_details', itr, 0) }</b><br>
                                    &nbsp;${ app.getArrayListVal('experience_details', itr, 1) }
                                </td>
                                <td style="padding: 10px; font-size: 14pt; font-weight: bold;">
                                    ${ app.monthDate( app.getArrayListVal('experience_details', itr, 2) ) } - ${ app.monthDate( app.getArrayListVal('experience_details', itr, 3) ) }
                                </td>
                            </tr>
                        `);
                    }
                }
            }
        }

        return list; 
    },

    getExperienceData2: function (id) {
        var list = "";

        if ( app.getArrayListVal('experience_details', 0, 0) != "") {

            var numRows = 1;
            for (var itr = 0; itr < JSON.parse(localStorage.getItem('experience_details')).length; itr++) {
                    
                if ( app.getArrayListVal('experience_details', itr, 0) != "") {

                    numRows++;
                }
            }

            list += (`<tr>
                            <td valign="top" rowspan="${numRows}" style="background-color: ${ app.getItem('basic_details', 'background') }; color: white; padding-left: 5px; font-weight: bold; border-bottom: 5px solid ${ app.getItem('basic_details', 'background') };">${id}:</td>
                            <td colspan="2" style="border-top: 5px solid ${ app.getItem('basic_details', 'background') };">
                    </td></tr>
                    `)

            if (JSON.parse(localStorage.getItem('experience_details')).length > 0) {
                for (var itr = 0; itr < JSON.parse(localStorage.getItem('experience_details')).length; itr++) {

                    if ( app.getArrayListVal('experience_details', itr, 0) != "") {
                        list += (`
                            <tr>
                                <td><font style="font-size: 20pt;">&#8226; &nbsp;</font><b>${ app.getArrayListVal('experience_details', itr, 0) }</b><br>
                                    &nbsp;${ app.getArrayListVal('experience_details', itr, 1) }
                                </td>
                                <td style="font-weight: bold;">
                                    ${ app.monthDate( app.getArrayListVal('experience_details', itr, 2) ) } - ${ app.monthDate( app.getArrayListVal('experience_details', itr, 3) ) }
                                </td>
                            </tr>
                        `);
                    }
                }
            }
        }

        return list; 
    },

    getProjectData: function (id) {
        var list = "";

        if ( app.getArrayListVal('project_details', 0, 0) != "") {

            list += (`<tr>
                        <td style="background-color: ${ app.getItem('basic_details', 'background') }; color: white; padding: 10px; font-size: 14pt; font-weight: bold;" colspan="4">${id}:</td>
                    </tr>`);
            if (JSON.parse(localStorage.getItem('project_details')).length > 0) {
                for (var itr = 0; itr < JSON.parse(localStorage.getItem('project_details')).length; itr++) {

                    if ( app.getArrayListVal('project_details', itr, 0) != "") {

                        list += (`
                            <tr>
                                <td style="padding: 10px; font-size: 14pt;" colspan="3"><font style="font-size: 20pt;">&#8226; &nbsp;</font><b>${ app.getArrayListVal('project_details', itr, 0) }</b><br>
                                    &nbsp;${ app.getArrayListVal('project_details', itr, 1) }
                                </td>
                                <td style="padding: 10px; font-size: 14pt; font-weight: bold;">
                                    ${ app.getArrayListVal('project_details', itr, 2) }
                                </td>
                            </tr>
                        `);
                    }
                }
            }
        }

        return list; 
    },

    getProjectData2: function (id) {
        var list = "";

        if ( app.getArrayListVal('project_details', 0, 0) != "") {

            var numRows = 1;
            for (var itr = 0; itr < JSON.parse(localStorage.getItem('project_details')).length; itr++) {
                    
                if ( app.getArrayListVal('project_details', itr, 0) != "") {

                    numRows++;
                }
            }

            list += (`<tr>
                            <td valign="top" rowspan="${numRows}" style="background-color: ${ app.getItem('basic_details', 'background') }; color: white; padding-left: 5px; font-weight: bold; border-bottom: 5px solid ${ app.getItem('basic_details', 'background') };">${id}:</td>
                            <td colspan="2" style="border-top: 5px solid ${ app.getItem('basic_details', 'background') };">
                    </td></tr>
                    `)

            if (JSON.parse(localStorage.getItem('project_details')).length > 0) {
                for (var itr = 0; itr < JSON.parse(localStorage.getItem('project_details')).length; itr++) {

                    if ( app.getArrayListVal('project_details', itr, 0) != "") {

                        list += (`
                            <tr>
                                <td><font style="font-size: 20pt;">&#8226; &nbsp;</font><b>${ app.getArrayListVal('project_details', itr, 0) }</b><br>
                                    &nbsp;${ app.getArrayListVal('project_details', itr, 1) }
                                </td>
                                <td>
                                    <b>${ app.getArrayListVal('project_details', itr, 2) }</b>
                                </td>
                            </tr>
                        `);
                    }
                }
            }

        }

        return list; 
    },

    getTechnicalData: function (id) {
        var list = "";

        if ( app.getArrayListVal('technical_details', 0, 0) != "") {

            list += (`<tr>
                        <td style="background-color: ${ app.getItem('basic_details', 'background') }; color: white; padding: 10px; font-size: 14pt; font-weight: bold;" colspan="4">${id}:</td>
                    </tr>`);
            if (JSON.parse(localStorage.getItem('technical_details')).length > 0) {
                for (var itr = 0; itr < JSON.parse(localStorage.getItem('technical_details')).length; itr++) {

                    if ( app.getArrayListVal('technical_details', itr, 0) != "") {

                        list += (`
                            <tr>
                                <td style="padding: 10px; font-size: 14pt;" colspan="3"><font style="font-size: 20pt;">&#8226; &nbsp;</font>${ app.getArrayListVal('technical_details', itr, 0) }
                                </td>
                            </tr>
                        `);
                    }
                }
            }
        }

        return list; 
    },

    getTechnicalData2: function (id) {
        var list = "";

        if ( app.getArrayListVal('technical_details', 0, 0) != "") {

            var numRows = 1;
            for (var itr = 0; itr < JSON.parse(localStorage.getItem('technical_details')).length; itr++) {
                    
                if ( app.getArrayListVal('technical_details', itr, 0) != "") {

                    numRows++;
                }
            }

            list += (`<tr>
                            <td valign="top" rowspan="${numRows}" style="background-color: ${ app.getItem('basic_details', 'background') }; color: white; padding-left: 5px; font-weight: bold; border-bottom: 5px solid ${ app.getItem('basic_details', 'background') };">${id}:</td>
                            <td colspan="2" style="border-top: 5px solid ${ app.getItem('basic_details', 'background') };">
                    </td></tr>
                    `)

            if (JSON.parse(localStorage.getItem('technical_details')).length > 0) {
                for (var itr = 0; itr < JSON.parse(localStorage.getItem('technical_details')).length; itr++) {

                    if ( app.getArrayListVal('technical_details', itr, 0) != "") {

                        list += (`
                            <tr>
                                <td colspan="2"><font style="font-size: 20pt;">&#8226; &nbsp;</font>${ app.getArrayListVal('technical_details', itr, 0) }</td>
                            </tr>
                        `);
                    }
                }
            }
        }

        return list; 
    },

    getInterestData: function (id) {
        var list = "";

        if ( app.getArrayListVal('interest_details', 0, 0) != "") {

            list += (`<tr>
                        <td style="background-color: ${ app.getItem('basic_details', 'background') }; color: white; padding: 10px; font-size: 14pt; font-weight: bold;" colspan="4">${id}:</td>
                    </tr>`);

            if (JSON.parse(localStorage.getItem('interest_details')).length > 0) {
                for (var itr = 0; itr < JSON.parse(localStorage.getItem('interest_details')).length; itr++) {

                    if ( app.getArrayListVal('interest_details', itr, 0) != "") {

                       list += (`
                            <tr>
                                <td style="padding: 10px; font-size: 14pt;" colspan="3"><font style="font-size: 20pt;">&#8226; &nbsp;</font>${ app.getArrayListVal('interest_details', itr, 0) }
                                </td>
                            </tr>
                        `);
                    }
                }
            }
        }

        return list; 
    },

    getInterestData2: function (id) {
        var list = "";

        if ( app.getArrayListVal('interest_details', 0, 0) != "") {

            var numRows = 1;
            for (var itr = 0; itr < JSON.parse(localStorage.getItem('interest_details')).length; itr++) {
                    
                if ( app.getArrayListVal('interest_details', itr, 0) != "") {

                    numRows++;
                }
            }

            list += (`<tr>
                            <td valign="top" rowspan="${numRows}" style="background-color: ${ app.getItem('basic_details', 'background') }; color: white; padding-left: 5px; font-weight: bold; border-bottom: 5px solid ${ app.getItem('basic_details', 'background') };">${id}:</td>
                            <td colspan="2" style="border-top: 5px solid ${ app.getItem('basic_details', 'background') };">
                    </td></tr>
                    `)

            if (JSON.parse(localStorage.getItem('interest_details')).length > 0) {
                for (var itr = 0; itr < JSON.parse(localStorage.getItem('interest_details')).length; itr++) {

                    if ( app.getArrayListVal('interest_details', itr, 0) != "") {

                       list += (`
                            <tr>
                                <td colspan="2"><font style="font-size: 20pt;">&#8226; &nbsp;</font>${ app.getArrayListVal('interest_details', itr, 0) }</td>
                            </tr>
                        `);
                    }
                }
            }
        }

        return list; 
    },

    getAchievementData: function (id) {
        var list = "";

        if ( app.getArrayListVal('achievement_details', 0, 0) != "") {

            list += (`<tr>
                        <td style="background-color: ${ app.getItem('basic_details', 'background') }; color: white; padding: 10px; font-size: 14pt; font-weight: bold;" colspan="4">${id}:</td>
                    </tr>`);
            if (JSON.parse(localStorage.getItem('achievement_details')).length > 0) {
                for (var itr = 0; itr < JSON.parse(localStorage.getItem('achievement_details')).length; itr++) {

                    if ( app.getArrayListVal('achievement_details', itr, 0) != "") {

                        list += (`
                            <tr>
                                <td style="padding: 10px; font-size: 14pt;" colspan="2"><font style="font-size: 20pt;">&#8226; &nbsp;</font>${ app.getArrayListVal('achievement_details', itr, 0) }
                                </td>
                            </tr>
                        `);
                    }
                }
            }
        }

        return list; 
    },

    getAchievementData2: function (id) {
        var list = "";

        if ( app.getArrayListVal('achievement_details', 0, 0) != "") {

            var numRows = 1;
            for (var itr = 0; itr < JSON.parse(localStorage.getItem('achievement_details')).length; itr++) {
                    
                if ( app.getArrayListVal('achievement_details', itr, 0) != "") {

                    numRows++;
                }
            }

            list += (`<tr>
                            <td valign="top" rowspan="${numRows}" style="background-color: ${ app.getItem('basic_details', 'background') }; color: white; padding-left: 5px; font-weight: bold; border-bottom: 5px solid ${ app.getItem('basic_details', 'background') };">${id}:</td>
                            <td colspan="2" style="border-top: 5px solid ${ app.getItem('basic_details', 'background') };">
                    </td></tr>
                    `) 
            if (JSON.parse(localStorage.getItem('achievement_details')).length > 0) {
                for (var itr = 0; itr < JSON.parse(localStorage.getItem('achievement_details')).length; itr++) {

                    if ( app.getArrayListVal('achievement_details', itr, 0) != "") {

                        list += (`
                            <tr>
                                <td colspan="2"><font style="font-size: 20pt;">&#8226; &nbsp;</font>${ app.getArrayListVal('achievement_details', itr, 0) }
                                </td>
                            </tr>
                        `);
                    }
                }
            }

        }

        return list; 
    },

    getTechnicalItems: function (id) {
        let list = JSON.parse(localStorage.getItem('technical_details'));

        if (list.length > 0) {

            var lists = "";
            for (var itr = 0; itr < list.length; itr++) {
                lists += (`
                    <form onsubmit="app.technicalForm(this, event, ${itr})" id="technical-form${itr}" method="post">
                        <div class="each-skill">
                            <h3>Skill ${ (itr+1) } <button type="button" onclick="app.removeSkill(this, ${itr})" class="btn btn-sm btn-danger">Delete</button></h3>
                            <div class="form-group">
                                <textarea id="skill${itr}" class="form-control input-lg" type="text" placeholder="(Example: Graphic Design)" required>${app.getArrayListVal('technical_details', itr, 0)}</textarea><br>
                            </div>
                        </div>

                        <hr>
                        <button type="submit" class="btn btn-block btn-primary btn-lg">Submit</button>
                        <hr>
                    </form>
                `)
            }

            $("#all-technicals").html(lists)
            $("#all-technicals").after(`<button type="button" onclick="app.setTechnicalItems(this)" class="btn btn-warning btn-block btn-lg">Add more</button>`)
        }
    },

    getInterestItems: function (id) {
        let list = JSON.parse(localStorage.getItem('interest_details'));

        if (list.length > 0) {

            var lists = "";
            for (var itr = 0; itr < list.length; itr++) {
                lists += (`
                    <form onsubmit="app.interestForm(this, event, ${itr})" id="interest-form${itr}" method="post">
                        <div class="each-interest">
                            <h3>Interest ${ (itr+1) } <button type="button" onclick="app.removeInterest(this, ${itr})" class="btn btn-sm btn-danger">Delete</button></h3>
                            <div class="form-group">
                                <textarea id="interest${itr}" class="form-control input-lg" type="text" placeholder="(Example: Graphic Design)" required>${app.getArrayListVal('interest_details', itr, 0)}</textarea><br>
                            </div>
                        </div>

                        <hr>
                        <button type="submit" class="btn btn-block btn-primary btn-lg">Submit</button>
                        <hr>
                    </form>
                `)
            }

            $("#all-interests").html(lists)
            $("#all-interests").after(`<button type="button" onclick="app.setInterestItems(this)" class="btn btn-warning btn-block btn-lg">Add more</button>`)
        }
    },

    getAchievementItems: function (id) {
        let list = JSON.parse(localStorage.getItem('achievement_details'));

        if (list.length > 0) {

            var lists = "";
            for (var itr = 0; itr < list.length; itr++) {
                lists += (`
                    <form onsubmit="app.achievementForm(this, event, ${itr})" id="achievement-form${itr}" method="post">
                        <div class="each-interest">
                            <h3>Achievement ${ (itr+1) } <button type="button" onclick="app.removeAchievement(this, ${itr})" class="btn btn-sm btn-danger">Delete</button></h3>
                            <div class="form-group">
                                <textarea id="achievement${itr}" class="form-control input-lg" type="text" placeholder="(Example: Computer Programming)" required>${app.getArrayListVal('achievement_details', itr, 0)}</textarea><br>
                            </div>
                        </div>

                        <hr>
                        <button type="submit" class="btn btn-block btn-primary btn-lg">Submit</button>
                        <hr>
                    </form>
                `)
            }

            $("#all-achievements").html(lists)
            $("#all-achievements").after(`<button type="button" onclick="app.setAchievementItems(this)" class="btn btn-warning btn-block btn-lg">Add more</button>`)
        }
    },

    getArrayListVal: function (tabl, index, keys) {
        let items = JSON.parse(localStorage.getItem(tabl));

        let value = items[index].list[keys];

        if (value == "[object Object]") {
            value = "";
        }            

        return value;
    },

    resetAllData: function () {

        if ( confirm('Are you sure you want to reset all Data and Preferences?\nNote: This can not be undone!') ) {
            app.setNewTechnicalItems(1);
            app.setNewReferenceItems(1);
            app.setNewProjectItems(1);
            app.setObjectiveItems(1);
            app.setNewInterestItems(1);
            app.setHobbiesItems(1);
            app.setNewExperienceItems(1);
            app.setNewEducationItems(1);
            app.setBasicItems(1);
            app.setNewAchievementItems(1);


            app.quickAlert('All Data and Preferences Were Successully Reset!');
        }
    },

    setNewEducationItems: function (opt) {

        let dbItem = localStorage.getItem('education_details');

        if ( !dbItem || opt == 1) {

            var items = [{
                            list: [
                                {institution: ''},
                                {course: ''},
                                {award: ''},
                                {startingDate: ''},
                                {endingDate: ''}
                            ]
                        }];

            window.localStorage.setItem('education_details', JSON.stringify(items));

        }
    },

    setNewInterestItems: function (opt) {

        let dbItem = localStorage.getItem('interest_details');

        if ( !dbItem || opt == 1 ) {

            var items = [{
                            list: [
                                {interest: ''}
                            ]
                        }];

            window.localStorage.setItem('interest_details', JSON.stringify(items));

        }
    },

    setNewReferenceItems: function (opt) {

        let dbItem = localStorage.getItem('reference_details');

        if ( !dbItem || opt == 1) {

            var items = [{
                            list: [
                                {names: ''},
                                {designation: ''},
                                {organisation: ''},
                                {email: ''},
                                {tel: ''}
                            ]
                        }];

            window.localStorage.setItem('reference_details', JSON.stringify(items));

        }
    },

    setReferenceItems: function () {

        let dbItem = localStorage.getItem('reference_details');

        if ( !dbItem ) {

            var items = [{
                            list: [
                                {names: ''},
                                {designation: ''},
                                {organisation: ''},
                                {email: ''},
                                {tel: ''}
                            ]
                        }];

            window.localStorage.setItem('reference_details', JSON.stringify(items));

        }else {

            var currentList = JSON.parse(localStorage.getItem('reference_details'));
            var news = {
                            list: [
                                {names: ''},
                                {designation: ''},
                                {organisation: ''},
                                {email: ''},
                                {tel: ''}
                            ]
                       };
                
            currentList.push(news);
            
            window.localStorage.setItem('reference_details', JSON.stringify(currentList));

        }

        window.location.reload();
    },

    setInterestItems: function () {

        let dbItem = localStorage.getItem('interest_details');

        if ( !dbItem ) {

            var items = [{
                            list: [
                                {interest: ''}
                            ]
                        }];

            window.localStorage.setItem('interest_details', JSON.stringify(items));

        }else {

            var currentList = JSON.parse(localStorage.getItem('interest_details'));
            var news = {
                            list: [
                                {interest: ''}
                            ]
                       };
                
            currentList.push(news);
            
            window.localStorage.setItem('interest_details', JSON.stringify(currentList));

        }

        window.location.reload();
    },

    setAchievementItems: function () {

        let dbItem = localStorage.getItem('achievement_details');

        if ( !dbItem ) {

            var items = [{
                            list: [
                                {interest: ''}
                            ]
                        }];

            window.localStorage.setItem('achievement_details', JSON.stringify(items));

        }else {

            var currentList = JSON.parse(localStorage.getItem('achievement_details'));
            var news = {
                            list: [
                                {interest: ''}
                            ]
                       };
                
            currentList.push(news);
            
            window.localStorage.setItem('achievement_details', JSON.stringify(currentList));

        }

        window.location.reload();
    },

    setNewExperienceItems: function (opt) {

        let dbItem = localStorage.getItem('experience_details');

        if ( !dbItem || opt == 1) {

            var items = [{
                            list: [
                                {organisation: ''},
                                {role: ''},
                                {startingDate: ''},
                                {endingDate: ''}
                            ]
                        }];

            window.localStorage.setItem('experience_details', JSON.stringify(items));

        }
    },

    setNewProjectItems: function (opt) {

        let dbItem = localStorage.getItem('project_details');

        if ( !dbItem || opt == 1) {

            var items = [{
                            list: [
                                {title: ''},
                                {desciption: ''},
                                {duration: ''}
                            ]
                        }];

            window.localStorage.setItem('project_details', JSON.stringify(items));

        }
    },

    setNewTechnicalItems: function (opt) {

        let dbItem = localStorage.getItem('technical_details');

        if ( !dbItem || opt == 1 ) {

            var items = [{
                            list: [
                                {skill: ''}
                            ]
                        }];

            window.localStorage.setItem('technical_details', JSON.stringify(items));

        }
    },

    setNewAchievementItems: function (opt) {

        let dbItem = localStorage.getItem('achievement_details');

        if ( !dbItem || opt == 1 ) {

            var items = [{
                            list: [
                                {skill: ''}
                            ]
                        }];

            window.localStorage.setItem('achievement_details', JSON.stringify(items));

        }
    },

    getDOB: function (dob) {

        var dobs = dob.split('-');
        
        var months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

        var redated = app.ordinal_suffix_of(dobs[2])+' '+months[dobs[1]-1]+', '+dobs[0];

        return redated;
    },

    monthDate: function (date) {
        var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

        var dates = date.split('-');

        var redated = months[dates[1]-1]+'. '+dates[0];

        return redated;
    },

    changeLayout: function () {

        $("div#layouts>a").each(function () {
            if ( $(this).hasClass('col-xs-6') ) {

                window.localStorage.setItem('layout', 'list'); 

                $(this).removeClass('col-xs-6')

            }else {

                $(this).addClass('col-xs-6');
                window.localStorage.setItem('layout', 'grid');                 

            }
        });
        
    },

    getPallets: function () {

        var lists = "";

        var palletTitle = app.getItem('basic_details', 'palletOrder');
        var palletOrder = app.getItem('basic_details', 'palletInOrder');

        lists += (`<ul id="sortable">
                    <li class="ui-state-default" data-value="${palletOrder[0]}">${palletTitle[0]}</li>
                    <li class="ui-state-default" data-value="${palletOrder[1]}">${palletTitle[1]}</li>
                    <li class="ui-state-default" data-value="${palletOrder[2]}">${palletTitle[2]}</li>
                    <li class="ui-state-default" data-value="${palletOrder[3]}">${palletTitle[3]}</li>
                    <li class="ui-state-default" data-value="${palletOrder[4]}">${palletTitle[4]}</li>
                    <li class="ui-state-default" data-value="${palletOrder[5]}">${palletTitle[5]}</li>
                    <li class="ui-state-default" data-value="${palletOrder[6]}">${palletTitle[6]}</li>
                    <li class="ui-state-default" data-value="${palletOrder[7]}">${palletTitle[7]}</li>
                    <li class="ui-state-default" data-value="${palletOrder[8]}">${palletTitle[8]}</li>
                    <li class="ui-state-default" data-value="${palletOrder[9]}">${palletTitle[9]}</li>
                </ul>`);

        $("#pallets-div").append(lists);

        (function($) {    
          $.iPhone = {        
            init: function() {            
              $(window).bind('orientationchange', $.iPhone.updateOrientation);            
              this.updateOrientation();            
              $('body').css({
                'min-height': '420px',
                'min-width': '320px'
              });        
            },
            orientation: 'portrait',
            updateOrientation: function()         {            
              this.orientation = (window.orientation === 0 || window.orientation == null || window.orientation === 180) ?  'portrait' : 'landscape';            
              $('body').attr('orient', this.orientation);            
              setTimeout($.iPhone.hideURL, 100);        
            },
            hideURL: function()         {            
              window.scrollTo(0, 1);            
              setTimeout(function() {                
                window.scrollTo(0, 0);            
              }, 0);        
            },
            preloadImages: function(images)         {                   
              $(images).each(function(key, val) {                
                (new Image()).src = val;                        
              });        
            }    
          };

              
          $.fn.addTouch = function()     {        
            this.each(function(i, el) {            
              $(el).bind('touchstart touchmove touchend touchcancel', function() {                 
                handleTouch(event);            
              });        
            });                
            var handleTouch = function(event)         {            
            var touches = event.changedTouches,
                            first = touches[0],
                            type = '';                        
              switch (event.type)             {                
                case 'touchstart':
                                      type = 'mousedown';                    
                  break;                                    
                case 'touchmove':
                                      type = 'mousemove';                    
                  break;                                        
                case 'touchend':
                                      type = 'mouseup';                    
                  break;                                    
                default:
                                      return;            
              }                        
              var simulatedEvent = document.createEvent('MouseEvent');            
              simulatedEvent.initMouseEvent(type, true, true, window, 1, first.screenX, first.screenY, first.clientX, first.clientY, false, false, false, false, 0 /*left*/ , null);                                                                             
              first.target.dispatchEvent(simulatedEvent);                        
              event.preventDefault();        
            };    
          };
        })(jQuery);

        $.iPhone.init();

        $(function() {
          $("#sortable").sortable().disableSelection().addTouch();
        });

    },

    chooseRearrange: function (id, index) {
        
        let value = $(id).val().trim();
        
        orderlist.push( $(id).val() )

        $(".each-pallets-layout").each(function() {
        
            $('option', this).each(function() {
                var value = $(this);
                
                if ( $.inArray(value.val(), orderlist ) !== -1 ) {
                    
                    value.attr("disabled", "disabled");
                }
                else {

                    value.removeAttr("disabled");
                }
            });

            
        });
    },

    getPalletsEdit: function () {

        var lists = "";

        if ( $("#pallets-edit-div").html().trim() == "" ) {
            

            var palletTitle = app.getItem('basic_details', 'palletOrder');

            $("#pallets-edit-div").append(`
                        <tr>
                            <th>1</th>
                            <td><input value="${palletTitle[0]}" class="form-control" id="each-pallets-edit1"></td>
                        </tr>
                        <tr>
                            <th>2</th>                        
                            <td><input value="${palletTitle[1]}" class="form-control" id="each-pallets-edit2"></td>
                        </tr>
                        <tr>
                            <th>3</th>
                            <td><input value="${palletTitle[2]}" class="form-control" id="each-pallets-edit3"></td>
                        </tr>
                        <tr>
                            <th>4</th>
                            <td><input value="${palletTitle[3]}" class="form-control" id="each-pallets-edit4"></td>
                        </tr>
                        <tr>
                            <th>5</th>
                            <td><input value="${palletTitle[4]}" class="form-control" id="each-pallets-edit5"></td>
                        </tr>
                        <tr>
                            <th>6</th>
                            <td><input value="${palletTitle[5]}" class="form-control" id="each-pallets-edit6"></td>
                        </tr>
                        <tr>
                            <th>7</th>
                            <td><input value="${palletTitle[6]}" class="form-control" id="each-pallets-edit7"></td>
                        </tr>
                        <tr>
                            <th>8</th>
                            <td><input value="${palletTitle[7]}" class="form-control" id="each-pallets-edit8"></td>
                        </tr>
                        <tr>
                            <th>9</th>
                            <td><input value="${palletTitle[8]}" class="form-control" id="each-pallets-edit9"></td>
                        </tr>
                        <tr>
                            <th>10</th>
                            <td><input value="${palletTitle[9]}" class="form-control" id="each-pallets-edit10"></td>
                        </tr>
                    </tr>`);
        }

    },

    checkOption: function (id, index) {
        
        if ( id == app.getItem('basic_details', 'palletOrder')[index] ) {

            return 'selected';
        }else {

            return '';
        }
    },   

    ordinal_suffix_of: function (i) {
        var j = i % 10,
            k = i % 100;
        if (j == 1 && k != 11) {
            return i + "st";
        }
        if (j == 2 && k != 12) {
            return i + "nd";
        }
        if (j == 3 && k != 13) {
            return i + "rd";
        }
        return i + "th";
    },

    removeEducation: function (this_, id) {
        
        $('#education-form'+id).remove();

        app.removeListItem('education_details', id); 
    },

    removeExperience: function (this_, id) {
        
        $('#experience-form'+id).remove();

        app.removeListItem('experience_details', id); 
    },

    removeReference: function (this_, id) {
        
        $('#reference-form'+id).remove();

        app.removeListItem('reference_details', id); 
    },

    removeAchievement: function (this_, id) {
        
        $('#achievement-form'+id).remove();

        app.removeListItem('achievement_details', id); 
    },

    removeInterest: function (this_, id) {
        
        $('#interest-form'+id).remove();

        app.removeListItem('interest_details', id); 
    },

    removeProject: function (this_, id) {
        
        $('#project-form'+id).remove();

        app.removeListItem('project_details', id);   
    },

    removeSkill: function (this_, id) {
        
        $('#technical-form'+id).remove();

        app.removeListItem('technical_details', id); 
    },

    removeListItem: function (tabl, id) {

        if(JSON.parse(localStorage.getItem(tabl)).length > 1) {
            var items = JSON.parse(localStorage.getItem(tabl));
            
            items.splice(id, 1);

            // console.log(keep)
            window.localStorage.setItem(tabl, JSON.stringify(items));
        }
    },

    setEducationItems: function () {

        let dbItem = localStorage.getItem('education_details');

        if ( !dbItem ) {

            var items = [{
                            list: [
                                {institution: ''},
                                {course: ''},
                                {award: ''},
                                {startingDate: ''},
                                {endingDate: ''}
                            ]
                        }];

            window.localStorage.setItem('education_details', JSON.stringify(items));

        }else {

            var currentList = JSON.parse(localStorage.getItem('education_details'));
            var news = {
                            list: [
                                {institution: ''},
                                {course: ''},
                                {award: ''},
                                {startingDate: ''},
                                {endingDate: ''}
                            ]
                       };
                
            currentList.push(news);
            
            window.localStorage.setItem('education_details', JSON.stringify(currentList));

        }

        window.location.reload();
    },

    setExperienceItems: function () {

        let dbItem = localStorage.getItem('experience_details');

        if ( !dbItem ) {

            var items = [{
                            list: [
                                {organisation: ''},
                                {role: ''},
                                {startingDate: ''},
                                {endingDate: ''}
                            ]
                        }];

            window.localStorage.setItem('experience_details', JSON.stringify(items));

        }else {

            var currentList = JSON.parse(localStorage.getItem('experience_details'));
            var news = {
                            list: [
                                {organisation: ''},
                                {role: ''},
                                {startingDate: ''},
                                {endingDate: ''}
                            ]
                       };
                
            currentList.push(news);
            
            window.localStorage.setItem('experience_details', JSON.stringify(currentList));

        }

        window.location.reload();
    },

    setProjectItems: function () {

        let dbItem = localStorage.getItem('project_details');

        if ( !dbItem ) {

            var items = [{
                            list: [
                                {title: ''},
                                {desciption: ''},
                                {duration: ''}
                            ]
                        }];

            window.localStorage.setItem('project_details', JSON.stringify(items));

        }else {

            var currentList = JSON.parse(localStorage.getItem('project_details'));
            var news = {
                            list: [
                                {title: ''},
                                {desciption: ''},
                                {duration: ''}
                            ]
                       };
                
            currentList.push(news);
            
            window.localStorage.setItem('project_details', JSON.stringify(currentList));

        }

        window.location.reload();
    },

    setTechnicalItems: function () {

        let dbItem = localStorage.getItem('technical_details');

        if ( !dbItem ) {

            var items = [{
                            list: [
                                {skill: ''}
                            ]
                        }];

            window.localStorage.setItem('technical_details', JSON.stringify(items));

        }else {

            var currentList = JSON.parse(localStorage.getItem('technical_details'));
            var news = {
                            list: [
                                {skill: ''}
                            ]
                       };
                
            currentList.push(news);
            
            window.localStorage.setItem('technical_details', JSON.stringify(currentList));

        }

        window.location.reload();
    },

    quickAlert: function (msg) {

        $(".quick-alert").text(msg);
        
        $(".quick-alert").slideDown();

        setTimeout( function() {

            $(".quick-alert").slideUp();

        }, 2000);
    },

    updateItem: function (tabl, keys, val) {
        var items = JSON.parse(localStorage.getItem(tabl));
        items[keys] = val;
        window.localStorage.setItem(tabl, JSON.stringify(items));
    },

    getItem: function (tabl, keys) {
        let items = JSON.parse(localStorage.getItem(tabl));

        return items[keys];
    }
};